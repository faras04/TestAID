import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;



public class Main {
	public static int NB_LIGNES=0;
	public static int NB_SESSIONS=0;
	public static HashMap<String, Integer> TAB_OCCURENCE_PAGES = new HashMap<String, Integer>();// tableau d occurence pour chaque page
	public static HashMap<String, Integer> TAB_OCCURENCE_SUITE_PAGES = new HashMap<String, Integer>(); //tableau d'occurence pour chaque suite de pages a=>b
	public static HashMap<String, Float> TAB_PROBAS = new HashMap<String, Float>();// tableau de probabilté pour chaque lien de a vers b

	/**
	 * fonction permettant de remplir le tableau d'occurence pour chaque page et renvoie le tableau contenant toutes les lignes du fichier
	 * @param fichier
	 * @return
	 * @throws IOException
	 */
	public static ArrayList<Ligne> lectureFichier(String fichier) throws IOException{
		ArrayList<Ligne> res =new ArrayList<Ligne>();
		/**Lecture du fichier*/
		InputStream ips;
		InputStreamReader ipsr;
		BufferedReader br;
		try {
			ips = new FileInputStream(fichier);
			ipsr = new InputStreamReader(ips);		
			br = new BufferedReader(ipsr);

			String line = br.readLine();
			line = br.readLine();
			//line = br.readLine();
			while ( (line!=null)){

				line = line.replaceAll("\t", "__");
				//System.out.println(line);
				String[] t = line.split("__");
				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy hh:mm");
				Date d = sdf.parse(t[1]);
				Ligne l = new Ligne(Integer.parseInt(t[0]),d,t[2]);
				if(TAB_OCCURENCE_PAGES.containsKey(t[2])){
					TAB_OCCURENCE_PAGES.replace(l.getPage(), TAB_OCCURENCE_PAGES.get(l.getPage()), TAB_OCCURENCE_PAGES.get(l.getPage())+1);
				}else{
					TAB_OCCURENCE_PAGES.put(l.getPage(), 1);
				}
				res.add(l);
				line = br.readLine();
				NB_LIGNES++;
			}
			br.close();
		}catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return res;
	}
    
	/**
	 * methode permettant d'afficher toutes les lignes du fichier
	 * @param fichier
	 * @throws IOException
	 */
	public static void afficheTableau(String fichier) throws IOException{

		ArrayList<Ligne> res = lectureFichier(fichier);

		for(Ligne l : res){

			System.out.println( "id: "+ l.getSeqId()+ " date: "+ l.getDate() + " page: "+ l.getPage());

		}
		System.out.println("taille : " + res.size());
	}
	
	/**
	 * methode d'affichage du tableau d'occurence de chaque pages
	 */
	public void afficheTabOccPages(){
		Set<String> pages = TAB_OCCURENCE_PAGES.keySet();
		Iterator it = pages.iterator();
		while(it.hasNext()){
			Object page = it.next();
			System.out.println(" page : "+ page + " nombre d'occurence : "+ TAB_OCCURENCE_PAGES.get(page));
		}
	}

	/**
	 * fonction renvoyant un tableau de chaque session onsidérées à partir de la durée
	 * @param tab
	 * @param dureeSession
	 * @return
	 */
	public static Session[] parcoursClient(ArrayList<Ligne> tab, int dureeSession){	
		Session[] res = new Session[NB_LIGNES];
		ArrayList<Ligne> tCopie = (ArrayList<Ligne>) tab.clone();
		Iterator<Ligne> itTab=tCopie.iterator(); 
		while(itTab.hasNext() && NB_SESSIONS<NB_LIGNES){

			Ligne l = itTab.next();
			//Cas où res est vide
			if(NB_SESSIONS==0){
				Session sNew = new Session(l.getSeqId(), l.getDate(), l.getPage(), dureeSession);
				res[NB_SESSIONS] = sNew;
				NB_SESSIONS++;
			}else{
				boolean trouve = false;
				for(int i = 0; i<NB_SESSIONS;i++){
					Session s = res[i];
					if( l.getSeqId() ==s.getSeqID() && ( l.getDate().compareTo(s.getDateFin())!=1 ) ){
						s.addParcours(l.getPage());
						trouve =true;
						break;
					}
				}
				if(!trouve){
					Session sNew = new Session(l.getSeqId(), l.getDate(), l.getPage(), dureeSession);
					res[NB_SESSIONS]= sNew;
					NB_SESSIONS++;
				}
			}
		}
		return res;
	}

	/**
	 * methode permettant d'afficher toutes les sessions 
	 * @param tab
	 * @param dureeSession
	 */
	public static void afficheSessions(ArrayList<Ligne> tab,int dureeSession){
		Session[] res = parcoursClient(tab,dureeSession);
		for(int i = 0;i<NB_SESSIONS;i++){	
			Session s = res[i];
			System.out.println(s.toStringSession());
		}


	}

	/**
	 * methode permettant de remplir 
	 * @param tabSession
	 */
	public static void tabOccAB(Session[] tabSession){
		for(int s = 0;s<NB_SESSIONS;s++){
			String[] tabParcours = tabSession[s].getParcours().split("=>");
			for(int i = 0;i<tabParcours.length-1;i++){
				int nbOcc = tabSession[s].getNbPageCS(tabParcours[i], tabParcours[i+1]);
				String suite = tabParcours[i]+"=>"+tabParcours[i+1];
				if(TAB_OCCURENCE_SUITE_PAGES.containsKey(suite)){
					Integer valAncien = TAB_OCCURENCE_SUITE_PAGES.get(suite);
					TAB_OCCURENCE_SUITE_PAGES.put(suite, valAncien+nbOcc);
					
				}else{
					TAB_OCCURENCE_SUITE_PAGES.put(suite, nbOcc);
				}
			}
		}
	}

	/**
	 * methode permettant l'affichage du du tableau du nombre d'occurence de chaque suite de pages	
	 * @param fichier
	 * @param dureeSession
	 */
	public static void afficheTabOcc(String fichier, int dureeSession){
		try {
			boolean test = false;
			tabOccAB(parcoursClient(lectureFichier(fichier), dureeSession));
			Set<String> suites = TAB_OCCURENCE_SUITE_PAGES.keySet();
			Iterator it = suites.iterator();
			while(it.hasNext()){
				Object suite = it.next();
				System.out.println(" suite : "+ suite + " nombre d'occurence : "+ TAB_OCCURENCE_SUITE_PAGES.get(suite));
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	/**
	 * methode permettant le remplissage du tableau des probabilites des suites de pages
	 */
	public static void calculProbaLiensSortants(){
		Set<String> pages = TAB_OCCURENCE_PAGES.keySet();
		Set<String> pages_copie = pages;
		Iterator it = pages.iterator();
		Iterator it2 = pages_copie.iterator();
		while(it.hasNext()){
			Object page = it.next();
			while(it2.hasNext()){
				Object page2 = it2.next();
				String sc= page+"=>"+page2;
				if(!page.equals(page2)){
					String suite = page2+"=>"+page;
					Float p = new Float(0);
					if(TAB_OCCURENCE_SUITE_PAGES.keySet().contains(suite)){
						p= (float)TAB_OCCURENCE_SUITE_PAGES.get(suite) / (float)TAB_OCCURENCE_PAGES.get(page);
						TAB_PROBAS.put(sc, p);
					}
				}
				
			}
			
		}
			
	}
	
	/**
	 * methode affichant la probabiltes pour chaque suite de page
	 */
	public static void afficheProbas(){
		Set<String> pages = TAB_PROBAS.keySet();
		Iterator it = pages.iterator();
		while(it.hasNext()){
			Object suite = it.next();
			System.out.println(" suite : "+ suite + " probas : "+ TAB_PROBAS.get(suite));
		}
	}

	/**
	 * fonction renvoyant la suite la plus probable
	 * @return
	 */
	public static Object calculPlusGrandProbas(){
		Object res ="";
		Set<String> pages = TAB_PROBAS.keySet();
		Iterator it = pages.iterator();
		Float p = new Float(0);
		while(it.hasNext()){
			Object suite = it.next();
			if(p<TAB_PROBAS.get(suite)){
				p=TAB_PROBAS.get(suite);
				res = suite;
			}
		}
		return res;
	}
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String fichier = "C:/Users/fatim_000/Desktop/test/AID/Sujet-data.txt";
		Scanner sc = new Scanner(System.in);
		int dureeDuneSession = 320;
		System.out.println("Si vous voulez saisir la durée (considérée) en minute d'une session taper 1 ");
		System.out.println("Sinon taper 2 pour la valeur par défaud qui est de 30 minutes :");
		if(sc.nextInt()==1){
			System.out.println("Veuillez indiquez la durée (considérée) en minute d'une session :");
			dureeDuneSession = sc.nextInt();
		}
		tabOccAB(parcoursClient(lectureFichier(fichier),dureeDuneSession));
		//afficheTabOcc(fichier, dureeDuneSession);
		calculProbaLiensSortants();
		//afficheProbas();
		Object suite = calculPlusGrandProbas();
		String[] page = ((String) suite).split("=>");
		System.out.println("La suite la plus probable est : "+suite+" avec une probabilité de  : "+TAB_PROBAS.get(suite)*100 +"%");
		System.out.println("La page cible la plus probable est donc : "+page[1]);
		
	}

}
