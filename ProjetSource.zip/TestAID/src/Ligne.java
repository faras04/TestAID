import java.util.Date;


public class Ligne {
	private int seqID;
	private Date date;
	private String page;
	
	Ligne(int id, Date d, String p){
		this.seqID = id;
		this.date = d;
		this.page = p;
	}
	
	public int getSeqId(){
		return this.seqID;
	}
	
	public Date getDate(){
		return this.date;
	}
	
	public String getPage(){
		return this.page;
	}
}
