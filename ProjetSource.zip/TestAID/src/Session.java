import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;


public class Session {
	private int seqID;
	private  Date dateDeb;
	private  Date dateFin;
	private String parcours;
	
	public Session(int id,Date d, String p, int dureeSession){
		this.seqID = id;
		this.dateDeb = d;		
		Calendar calendar = Calendar.getInstance();
		Date cDDeb = (Date) this.dateDeb.clone();
		calendar.setTime(cDDeb);
		calendar.add(Calendar.MINUTE, dureeSession);
		this.dateFin = new Date(calendar.getTimeInMillis());
		this.parcours = p;
	}
	
	public Session(){
		this.seqID = 0;
		GregorianCalendar calendar = new java.util.GregorianCalendar(); 
		this.dateDeb = calendar.getTime();
		this.dateFin = calendar.getTime();
		this.parcours = "";
	}
	
	public String getParcours(){
		return this.parcours;
	}
	
	public void addParcours(String p){
		this.parcours= this.parcours.concat("=>"+p);
	}
	
	public int getSeqID(){
		return this.seqID;
	}
	
	public Date  getDateFin(){
		return this.dateFin;
	}
	
	public Date  getDateDeb(){
		return this.dateFin;
	}
	
	public  String toStringSession(){
		return " seqID : "+this.seqID +" parcours : "+ this.parcours +" dateDeb : "+ this.dateDeb +" dateFin : "+ this.dateFin;
	}
	
	//le nombre d'occurence d'une page p
	public int getNbOccurencePageCible(String p){
		int res = 0;
		String[] t =this.parcours.split("=>");
		for(String s:t){
			if(s.equals(p)){
				res++;
			}
		}
		return res;
	}
	
	//retourne le nombre d'occurence d'aller d'une page p1 vers une page p2
	public int getNbPageCS(String p1, String p2){
		int res = 0;
		String[] t =this.parcours.split("=>");
		for(int i = 1;i<t.length-2;i++){
			if(t[i].equals(p1) && t[i+1].equals(p2)){
				res++;
			}
		}
		return res;
	}
}
